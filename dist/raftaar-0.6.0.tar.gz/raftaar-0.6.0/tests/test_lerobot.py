"""LeRobot adapter tests.

The fixtures below write the LeRobotDataset v2.x layout as published on the
Hugging Face Hub -- `meta/info.json`, `meta/episodes.jsonl`, `meta/tasks.jsonl`
and `data/chunk-000/episode_*.parquet` -- rather than mocking the reader. The
adapter tracks a file format, so the tests have to exercise the file format.

Two robot shapes are covered, because they are the two the adapter has to tell
apart:

* a **joint-space arm** with a named gripper, the SO-100/SO-101 convention that
  most of the hub follows
* a **Cartesian** dataset whose state columns are named `ee_x`/`ee_y`/`ee_z`

Getting the second wrong is the expensive failure: treating joint angles as a
position produces numbers that look entirely plausible and mean nothing.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pytest

pytest.importorskip("pyarrow")

from raftaar import scan
from raftaar.lerobot import (
    LeRobotFormatError,
    infer_gripper_dim,
    infer_spatial_dims,
    load_lerobot,
    segment_phases,
)

JOINT_NAMES = ["shoulder_pan", "shoulder_lift", "elbow_flex",
               "wrist_flex", "wrist_roll", "gripper"]
CARTESIAN_NAMES = ["ee_x", "ee_y", "ee_z", "gripper"]


def _write_lerobot(root: Path, n_episodes=40, n_frames=60, names=JOINT_NAMES,
                   seed=0, bimodal=False, codebase_version="v2.1"):
    """Write a minimal but structurally faithful LeRobotDataset."""
    import pyarrow as pa
    import pyarrow.parquet as pq

    rng = np.random.default_rng(seed)
    n_dims = len(names)
    (root / "meta").mkdir(parents=True, exist_ok=True)
    (root / "data" / "chunk-000").mkdir(parents=True, exist_ok=True)

    episodes_meta = []
    for ep in range(n_episodes):
        t = np.linspace(0, 1, n_frames)
        state = np.zeros((n_frames, n_dims), dtype="float32")

        # A reach whose mid-trajectory detour goes one way or the other. With
        # `bimodal` the two groups are separated; without it they are one blob.
        side = 1.0 if (bimodal and ep % 2 == 0) else (-1.0 if bimodal else 0.0)
        target = rng.uniform(-1, 1, size=3)
        for d in range(min(3, n_dims)):
            state[:, d] = (t * target[d]
                           + side * 0.6 * np.sin(np.pi * t)
                           + rng.normal(0, 0.02, n_frames))
        for d in range(3, n_dims - 1):
            state[:, d] = rng.normal(0, 0.05, n_frames)

        # Gripper: open, closed through the middle, open again.
        gripper = np.ones(n_frames, dtype="float32")
        gripper[n_frames // 3: 2 * n_frames // 3] = 0.0
        state[:, -1] = gripper

        action = np.diff(state, axis=0, prepend=state[:1]).astype("float32")

        table = pa.table({
            "observation.state": pa.array(state.tolist()),
            "action": pa.array(action.tolist()),
            "timestamp": pa.array((np.arange(n_frames) / 30.0).tolist()),
            "frame_index": pa.array(np.arange(n_frames).tolist()),
            "episode_index": pa.array([ep] * n_frames),
            "index": pa.array((np.arange(n_frames) + ep * n_frames).tolist()),
            "task_index": pa.array([0] * n_frames),
        })
        pq.write_table(table, root / "data" / "chunk-000"
                       / f"episode_{ep:06d}.parquet")
        episodes_meta.append({"episode_index": ep, "tasks": ["pick up the cube"],
                              "length": n_frames})

    (root / "meta" / "info.json").write_text(json.dumps({
        "codebase_version": codebase_version,
        "repo_id": "test/fixture",
        "robot_type": "so100",
        "fps": 30,
        "total_episodes": n_episodes,
        "total_frames": n_episodes * n_frames,
        "chunks_size": 1000,
        "features": {
            "observation.state": {"dtype": "float32", "shape": [n_dims],
                                  "names": names},
            "action": {"dtype": "float32", "shape": [n_dims], "names": names},
        },
    }, indent=2))
    (root / "meta" / "episodes.jsonl").write_text(
        "\n".join(json.dumps(e) for e in episodes_meta))
    (root / "meta" / "tasks.jsonl").write_text(
        json.dumps({"task_index": 0, "task": "pick up the cube"}))
    return root


@pytest.fixture(scope="module")
def joint_dataset(tmp_path_factory):
    return _write_lerobot(tmp_path_factory.mktemp("lerobot") / "joints")


# --------------------------------------------------------------------------
# reading the format
# --------------------------------------------------------------------------

class TestLoading:
    def test_reads_a_lerobot_directory(self, joint_dataset):
        data = load_lerobot(joint_dataset)

        assert len(data["episodes"]) == 40
        episode = data["episodes"][0]
        assert episode["observation.state"].shape == (60, 6)
        assert episode["action"].shape == (60, 6)
        assert len(episode["phase"]) == 60

    def test_does_not_import_lerobot_or_torch(self, joint_dataset):
        """The whole point of reading the format rather than the library."""
        import subprocess
        import sys

        code = (
            "import sys; from raftaar.lerobot import load_lerobot; "
            f"load_lerobot({str(joint_dataset)!r}); "
            "bad=[m for m in ('torch','lerobot','torchvision') if m in sys.modules]; "
            "assert not bad, bad; print('ok')"
        )
        out = subprocess.run([sys.executable, "-c", code],
                             capture_output=True, text=True)
        assert out.returncode == 0, out.stderr
        assert "ok" in out.stdout

    def test_max_episodes_reads_a_prefix(self, joint_dataset):
        assert len(load_lerobot(joint_dataset, max_episodes=5)["episodes"]) == 5

    def test_metadata_is_carried_through(self, joint_dataset):
        info = load_lerobot(joint_dataset)["info"]

        assert info["dataset_name"] == "test/fixture"
        assert info["robot_type"] == "so100"
        assert info["fps"] == 30
        assert info["_adapter"]["codebase_version"] == "v2.1"
        assert "pick up the cube" in info["_adapter"]["tasks"]

    def test_a_non_lerobot_directory_says_so(self, tmp_path):
        (tmp_path / "data").mkdir()
        with pytest.raises(LeRobotFormatError) as exc:
            load_lerobot(tmp_path)
        assert "meta/info.json" in str(exc.value)

    def test_scan_runs_on_an_adapted_dataset(self, joint_dataset):
        report = scan(load_lerobot(joint_dataset))

        assert report["n_episodes"] == 40
        assert report["n_frames"] == 40 * 60
        assert isinstance(report["findings"], list)


# --------------------------------------------------------------------------
# the two inferences the adapter has to make
# --------------------------------------------------------------------------

class TestSpatialDims:
    def test_cartesian_columns_are_found_by_name(self):
        dims, how = infer_spatial_dims(CARTESIAN_NAMES, 4)
        assert dims == [0, 1, 2]
        assert how == "cartesian-by-name"

    def test_joint_space_falls_back_and_says_so(self):
        """The label matters more than the choice.

        Comparing the first three joints is defensible; calling it a position
        is not. A scan that silently treated joint angles as xyz would produce
        plausible numbers that mean something different.
        """
        dims, how = infer_spatial_dims(JOINT_NAMES, 6)
        assert dims == [0, 1, 2]
        assert how == "first-3-joints"

    def test_the_choice_reaches_the_manifest(self, joint_dataset):
        info = load_lerobot(joint_dataset)["info"]
        assert info["spatial_dims"] == [0, 1, 2]
        assert info["_adapter"]["spatial_dims_from"] == "first-3-joints"

    def test_cartesian_dataset_is_labelled_differently(self, tmp_path):
        root = _write_lerobot(tmp_path / "cart", n_episodes=20,
                              names=CARTESIAN_NAMES)
        info = load_lerobot(root)["info"]
        assert info["_adapter"]["spatial_dims_from"] == "cartesian-by-name"


class TestGripperAndPhases:
    def test_gripper_is_found_by_name(self):
        assert infer_gripper_dim(JOINT_NAMES) == 5
        assert infer_gripper_dim(CARTESIAN_NAMES) == 3

    def test_gripper_falls_back_to_the_last_channel(self):
        actions = np.zeros((10, 4))
        assert infer_gripper_dim(None, actions) == 3

    def test_phases_follow_the_gripper(self, joint_dataset):
        data = load_lerobot(joint_dataset)
        assert data["info"]["_adapter"]["phase_method"] == "gripper"

        phases = data["episodes"][0]["phase"]
        assert set(phases) == {"approach", "transport", "release"}
        # Order matters: approach precedes transport precedes release.
        first = {p: int(np.argmax(phases == p)) for p in set(phases.tolist())}
        assert first["approach"] < first["transport"] < first["release"]

    def test_without_a_gripper_it_splits_into_thirds_and_says_so(self):
        """A weak segmentation is still better than skipping the dataset --
        provided the record says it was a guess."""
        states = np.random.default_rng(0).normal(size=(60, 5))
        actions = np.diff(states, axis=0, prepend=states[:1])

        phases, method = segment_phases(actions, states, gripper_dim=None)
        assert method == "thirds"
        assert set(phases) == {"approach", "transport", "release"}

    def test_a_constant_gripper_falls_back_to_thirds(self):
        """A channel that never moves carries no boundary information."""
        states = np.zeros((60, 6))
        states[:, 5] = 1.0
        actions = np.zeros((60, 6))

        _, method = segment_phases(actions, states, gripper_dim=5)
        assert method == "thirds"

    def test_empty_episode_does_not_crash(self):
        phases, method = segment_phases(np.zeros((0, 4)), np.zeros((0, 4)), 3)
        assert len(phases) == 0
        assert method == "empty"


# --------------------------------------------------------------------------
# what the detectors do with adapted data
# --------------------------------------------------------------------------

class TestDetectionOnAdaptedData:
    def test_bimodal_strategies_are_caught_through_the_adapter(self, tmp_path):
        """End to end: parquet on disk, through the adapter, to a finding."""
        root = _write_lerobot(tmp_path / "bi", n_episodes=60, bimodal=True,
                              seed=1)
        report = scan(load_lerobot(root))
        assert "AVERAGING_HAZARD" in {f["id"] for f in report["findings"]}

    def test_unimodal_data_does_not_raise_the_hazard(self, tmp_path):
        root = _write_lerobot(tmp_path / "uni", n_episodes=60, bimodal=False,
                              seed=1)
        report = scan(load_lerobot(root))
        assert "AVERAGING_HAZARD" not in {f["id"] for f in report["findings"]}

    def test_missing_image_features_are_reported_not_assumed(self, joint_dataset):
        """No hub dataset ships precomputed image features.

        Reporting "no shards" there would claim a check that never ran.
        """
        report = scan(load_lerobot(joint_dataset))

        assert report["shards"]["available"] is False
        assert "not assessed" in report["shards"]["reason"]
        assert "REPRESENTATION_SHARD" not in {f["id"] for f in report["findings"]}


# --------------------------------------------------------------------------
# the CLI path
# --------------------------------------------------------------------------

class TestCLIWithLeRobot:
    def test_format_is_detected_from_the_directory(self, tmp_path):
        """Both formats carry meta/info.json, so the data files decide."""
        from raftaar.cli import detect_format

        lerobot = _write_lerobot(tmp_path / "lr", n_episodes=10)
        assert detect_format(lerobot) == "lerobot"

        from raftaar import DatasetSpec, FaultSpec, build_dataset
        native = build_dataset(
            DatasetSpec(name="native", n_episodes=10, seed=0, faults=FaultSpec()),
            tmp_path / "d")
        assert detect_format(Path(native)) == "raftaar"

        (tmp_path / "empty").mkdir()
        assert detect_format(tmp_path / "empty") == "unknown"

    def test_scan_runs_end_to_end_on_a_lerobot_directory(self, tmp_path):
        import json
        import subprocess

        root = _write_lerobot(tmp_path / "hub", n_episodes=30, bimodal=True,
                              seed=2)
        out = subprocess.run(
            ["raftaar", "scan", str(root), "--out", str(tmp_path / "r")],
            capture_output=True, text=True)
        assert out.returncode == 0, out.stderr

        # The interpretation is announced, not silent.
        assert "read as LeRobotDataset" in out.stdout
        assert "phases by gripper" in out.stdout

        report = json.loads((tmp_path / "r" / "report.json").read_text())
        assert report["adapter"]["source"] == "lerobot"
        assert report["adapter"]["phase_method"] == "gripper"

        # And it reaches the human-readable report too.
        markdown = (tmp_path / "r" / "report.md").read_text()
        assert "How this dataset was read" in markdown
        assert "not assessed" in markdown

    def test_max_episodes_is_honoured_by_the_cli(self, tmp_path):
        import json
        import subprocess

        root = _write_lerobot(tmp_path / "big", n_episodes=40)
        subprocess.run(["raftaar", "scan", str(root), "--out", str(tmp_path / "r"),
                        "--max-episodes", "12"], capture_output=True, text=True)
        report = json.loads((tmp_path / "r" / "report.json").read_text())
        assert report["n_episodes"] == 12

    def test_a_directory_of_neither_format_fails_clearly(self, tmp_path):
        import subprocess

        (tmp_path / "junk" / "data").mkdir(parents=True)
        out = subprocess.run(["raftaar", "scan", str(tmp_path / "junk")],
                             capture_output=True, text=True)
        assert out.returncode != 0
        combined = out.stdout + out.stderr
        assert "neither" in combined and "--format" in combined

    def test_the_figure_renders_without_image_features(self, tmp_path):
        """The fourth panel plots image features; most datasets have none."""
        pytest.importorskip("matplotlib")
        from raftaar.report import plot

        root = _write_lerobot(tmp_path / "nofeat", n_episodes=20)
        data = load_lerobot(root)
        out = tmp_path / "fig.png"
        plot(data, scan(data), out)
        assert out.stat().st_size > 5000


def _write_lerobot_v3(root: Path, n_episodes=30, n_frames=50,
                      episodes_per_file=10, names=JOINT_NAMES, seed=0):
    """LeRobotDataset v3.0: many episodes concatenated into one parquet file.

    v3 packs episodes together to keep file counts manageable at hub scale. A
    reader that assumes one episode per file does not fail on these -- it glues
    every episode in the file into a single trajectory and scans that, which
    produces numbers rather than an error.
    """
    import pyarrow as pa
    import pyarrow.parquet as pq

    rng = np.random.default_rng(seed)
    n_dims = len(names)
    (root / "meta").mkdir(parents=True, exist_ok=True)
    (root / "data" / "chunk-000").mkdir(parents=True, exist_ok=True)

    ep = 0
    for file_no in range((n_episodes + episodes_per_file - 1) // episodes_per_file):
        rows = {k: [] for k in ("observation.state", "action", "timestamp",
                                "frame_index", "episode_index", "index",
                                "task_index")}
        for _ in range(min(episodes_per_file, n_episodes - ep)):
            t = np.linspace(0, 1, n_frames)
            state = np.zeros((n_frames, n_dims), dtype="float32")
            target = rng.uniform(-1, 1, size=3)
            for d in range(min(3, n_dims)):
                state[:, d] = t * target[d] + rng.normal(0, 0.02, n_frames)
            gripper = np.ones(n_frames, dtype="float32")
            gripper[n_frames // 3: 2 * n_frames // 3] = 0.0
            state[:, -1] = gripper
            action = np.diff(state, axis=0, prepend=state[:1]).astype("float32")

            rows["observation.state"] += state.tolist()
            rows["action"] += action.tolist()
            rows["timestamp"] += (np.arange(n_frames) / 30.0).tolist()
            rows["frame_index"] += np.arange(n_frames).tolist()
            rows["episode_index"] += [ep] * n_frames
            rows["index"] += (np.arange(n_frames) + ep * n_frames).tolist()
            rows["task_index"] += [0] * n_frames
            ep += 1

        pq.write_table(pa.table(rows),
                       root / "data" / "chunk-000" / f"file-{file_no:04d}.parquet")

    (root / "meta" / "info.json").write_text(json.dumps({
        "codebase_version": "v3.0",
        "repo_id": "test/fixture-v3",
        "robot_type": "so101",
        "fps": 30,
        "total_episodes": n_episodes,
        "features": {
            "observation.state": {"dtype": "float32", "shape": [n_dims],
                                  "names": names},
            "action": {"dtype": "float32", "shape": [n_dims], "names": names},
        },
    }, indent=2))
    (root / "meta" / "tasks.jsonl").write_text(
        json.dumps({"task_index": 0, "task": "pick up the cube"}))
    # v3 stores episode metadata as chunked parquet, not episodes.jsonl.
    return root


class TestV3Layout:
    """v3.0 packs many episodes per file. Splitting on `episode_index` handles
    both formats; assuming one episode per file silently merges them."""

    def test_episodes_are_split_out_of_multi_episode_files(self, tmp_path):
        root = _write_lerobot_v3(tmp_path / "v3", n_episodes=30,
                                 episodes_per_file=10)
        data = load_lerobot(root)

        # 3 files, 30 episodes -- not 3.
        assert len(data["episodes"]) == 30
        for episode in data["episodes"]:
            assert episode["observation.state"].shape[0] == 50

    def test_v3_reports_its_codebase_version(self, tmp_path):
        root = _write_lerobot_v3(tmp_path / "v3b", n_episodes=10,
                                 episodes_per_file=10)
        info = load_lerobot(root)["info"]
        assert info["_adapter"]["codebase_version"] == "v3.0"
        assert info["_adapter"]["episodes_read"] == 10

    def test_missing_episodes_jsonl_is_not_fatal(self, tmp_path):
        """v3 replaced episodes.jsonl with chunked parquet under meta/episodes/."""
        root = _write_lerobot_v3(tmp_path / "v3c", n_episodes=12,
                                 episodes_per_file=6)
        assert not (root / "meta" / "episodes.jsonl").exists()
        assert len(load_lerobot(root)["episodes"]) == 12

    def test_max_episodes_counts_episodes_not_files(self, tmp_path):
        """One v3 file can hold forty episodes, so slicing the file list would
        read far more than asked for."""
        root = _write_lerobot_v3(tmp_path / "v3d", n_episodes=30,
                                 episodes_per_file=10)
        assert len(load_lerobot(root, max_episodes=7)["episodes"]) == 7

    def test_scan_runs_on_a_v3_dataset(self, tmp_path):
        root = _write_lerobot_v3(tmp_path / "v3e", n_episodes=40,
                                 episodes_per_file=20)
        report = scan(load_lerobot(root))
        assert report["n_episodes"] == 40
        assert report["n_frames"] == 40 * 50


class TestSpreadSampling:
    """`max_episodes` reads a prefix by default, which is wrong for calibration.

    Hub datasets are written in collection order, so the first N episodes of a
    large dataset often come from one session by one operator. A comparison
    against `collector_id` then has a single-level grouping and cannot run --
    which looks like a null result and is really a sampling artefact.
    """

    def _multi_file(self, tmp_path, n_files=8, per_file=10, n_frames=40):
        """One collector per file: the shape DROID has."""
        import pyarrow as pa
        import pyarrow.parquet as pq

        root = tmp_path / "ds"
        (root / "meta" / "episodes").mkdir(parents=True, exist_ok=True)
        (root / "data" / "chunk-000").mkdir(parents=True, exist_ok=True)
        rng = np.random.default_rng(0)
        meta = {"episode_index": [], "length": [], "collector_id": []}
        ep = 0
        for f in range(n_files):
            rows = {k: [] for k in ("observation.state", "action",
                                    "episode_index", "frame_index")}
            for _ in range(per_file):
                t = np.linspace(0, 1, n_frames)
                state = np.zeros((n_frames, 6), dtype="float32")
                for d in range(3):
                    state[:, d] = t * rng.uniform(-1, 1)
                gripper = np.ones(n_frames, dtype="float32")
                gripper[n_frames // 3: 2 * n_frames // 3] = 0.0
                state[:, 5] = gripper
                rows["observation.state"] += state.tolist()
                rows["action"] += np.diff(
                    state, axis=0, prepend=state[:1]).astype("float32").tolist()
                rows["episode_index"] += [ep] * n_frames
                rows["frame_index"] += list(range(n_frames))
                meta["episode_index"].append(ep)
                meta["length"].append(n_frames)
                meta["collector_id"].append(f"operator_{f}")
                ep += 1
            pq.write_table(pa.table(rows),
                           root / "data" / "chunk-000" / f"file-{f:04d}.parquet")
        pq.write_table(pa.table(meta),
                       root / "meta" / "episodes" / "chunk-000.parquet")
        names = ["j0", "j1", "j2", "j3", "j4", "gripper"]
        (root / "meta" / "info.json").write_text(json.dumps({
            "codebase_version": "v3.0", "repo_id": "t/ds", "fps": 30,
            "total_episodes": ep,
            "features": {
                "observation.state": {"dtype": "float32", "shape": [6],
                                      "names": names},
                "action": {"dtype": "float32", "shape": [6], "names": names},
            }}))
        return root

    def test_prefix_collapses_the_grouping(self, tmp_path):
        from raftaar.calibration import episode_groups

        root = self._multi_file(tmp_path)
        data = load_lerobot(root, max_episodes=20)
        groups = episode_groups(data, "collector_id")

        assert len(data["episodes"]) == 20
        # 20 episodes at 10 per file: only the first two files are touched.
        assert len(set(groups)) == 2
        assert data["info"]["_adapter"]["sampling"] == "prefix"

    def test_spread_covers_every_file_on_the_same_budget(self, tmp_path):
        from raftaar.calibration import episode_groups

        root = self._multi_file(tmp_path)
        data = load_lerobot(root, max_episodes=20, spread=True)
        groups = episode_groups(data, "collector_id")

        assert len(data["episodes"]) <= 20
        assert len(set(groups)) == 8, "every file should contribute"
        assert data["info"]["_adapter"]["sampling"] == "spread across files"

    def test_spread_without_a_budget_reads_everything(self, tmp_path):
        root = self._multi_file(tmp_path)
        assert len(load_lerobot(root, spread=True)["episodes"]) == 80


class TestStringGroupingColumns:
    """String columns must survive the reader.

    `_load_table` used to keep only numeric and list columns, on the grounds
    that "the detectors do not use strings". True of the detectors and false of
    everything else: `collector_id`, `building` and `task_category` are strings,
    and they are the only labels on the hub that can act as ground truth for a
    detected strategy split.

    The failure was silent and misleading -- every string-valued grouping key
    reported as absent, which reads as "this dataset has no operator labels"
    when it has them. Found on `lerobot/droid_1.0.1`, where the only key that
    survived was the one integer among them, `task_index`.
    """

    def _with_string_columns(self, tmp_path, n_files=4, per_file=6, n_frames=40):
        import pyarrow as pa
        import pyarrow.parquet as pq

        root = tmp_path / "ds"
        (root / "meta").mkdir(parents=True, exist_ok=True)
        (root / "data" / "chunk-000").mkdir(parents=True, exist_ok=True)
        rng = np.random.default_rng(0)
        ep = 0
        for f in range(n_files):
            rows = {k: [] for k in ("observation.state", "action",
                                    "episode_index", "collector_id",
                                    "building", "task_index")}
            for _ in range(per_file):
                t = np.linspace(0, 1, n_frames)
                state = np.zeros((n_frames, 6), dtype="float32")
                for d in range(3):
                    state[:, d] = t * rng.uniform(-1, 1)
                gripper = np.ones(n_frames, dtype="float32")
                gripper[n_frames // 3: 2 * n_frames // 3] = 0.0
                state[:, 5] = gripper
                rows["observation.state"] += state.tolist()
                rows["action"] += np.diff(
                    state, axis=0, prepend=state[:1]).astype("float32").tolist()
                rows["episode_index"] += [ep] * n_frames
                rows["collector_id"] += [f"user_{f}"] * n_frames
                rows["building"] += [f"site_{f % 2}"] * n_frames
                rows["task_index"] += [0] * n_frames
                ep += 1
            pq.write_table(pa.table(rows),
                           root / "data" / "chunk-000" / f"file-{f:04d}.parquet")
        names = ["j0", "j1", "j2", "j3", "j4", "gripper"]
        (root / "meta" / "info.json").write_text(json.dumps({
            "codebase_version": "v3.0", "repo_id": "t/ds", "fps": 30,
            "total_episodes": ep,
            "features": {
                "observation.state": {"dtype": "float32", "shape": [6],
                                      "names": names},
                "action": {"dtype": "float32", "shape": [6], "names": names},
            }}))
        return root

    def test_string_grouping_keys_are_found(self, tmp_path):
        from raftaar.calibration import episode_groups

        root = self._with_string_columns(tmp_path)
        data = load_lerobot(root, spread=True)

        keys = data["info"]["_adapter"]["grouping_keys"]
        assert "collector_id" in keys
        assert "building" in keys

        collectors = episode_groups(data, "collector_id")
        assert collectors is not None
        assert len(set(collectors)) == 4
        assert all(isinstance(c, str) for c in collectors)

    def test_string_values_survive_intact(self, tmp_path):
        """Not coerced to float and not stringified into something else."""
        from raftaar.calibration import episode_groups

        root = self._with_string_columns(tmp_path)
        data = load_lerobot(root, spread=True)
        assert set(episode_groups(data, "building")) == {"site_0", "site_1"}

    def test_numeric_columns_still_work(self, tmp_path):
        """The fix must not disturb the columns that already worked."""
        root = self._with_string_columns(tmp_path)
        data = load_lerobot(root, spread=True)
        assert "task_index" in data["info"]["_adapter"]["grouping_keys"]
        assert data["episodes"][0]["observation.state"].dtype == np.float32


class TestTasksGrouping:
    """`tasks` from `meta/episodes/*.parquet` is the positive control.

    It is per-episode, semantically bound to separate trajectories, and
    independent of recording conditions -- which `collector_id` and `building`
    are not. It arrives as a *list of strings*, so it has to be collapsed to
    something hashable before a partition can be built from it.
    """

    def _tasks_dataset(self, tmp_path, n_files=4, per_file=15, n_frames=40,
                       distinct=True):
        import pyarrow as pa
        import pyarrow.parquet as pq

        root = tmp_path / "ds"
        (root / "meta" / "episodes").mkdir(parents=True, exist_ok=True)
        (root / "data" / "chunk-000").mkdir(parents=True, exist_ok=True)
        rng = np.random.default_rng(0)
        names_of_tasks = ["lift", "drawer", "stack"]
        meta = {"episode_index": [], "length": [], "tasks": []}
        ep = 0
        for f in range(n_files):
            rows = {k: [] for k in ("observation.state", "action",
                                    "episode_index", "frame_index")}
            for _ in range(per_file):
                task = ep % 3
                t = np.linspace(0, 1, n_frames)
                state = np.zeros((n_frames, 6), dtype="float32")
                detour = [1.2, -1.2, 0.0][task] if distinct else 0.0
                state[:, 0] = t + rng.normal(0, 0.02, n_frames)
                state[:, 1] = detour * np.sin(np.pi * t) + rng.normal(0, 0.02, n_frames)
                state[:, 2] = ([0.0, 0.0, 1.0][task] if distinct else 0.0) * t
                gripper = np.ones(n_frames, dtype="float32")
                gripper[n_frames // 3: 2 * n_frames // 3] = 0.0
                state[:, 5] = gripper
                rows["observation.state"] += state.tolist()
                rows["action"] += np.diff(
                    state, axis=0, prepend=state[:1]).astype("float32").tolist()
                rows["episode_index"] += [ep] * n_frames
                rows["frame_index"] += list(range(n_frames))
                meta["episode_index"].append(ep)
                meta["length"].append(n_frames)
                meta["tasks"].append([names_of_tasks[task]])
                ep += 1
            pq.write_table(pa.table(rows),
                           root / "data" / "chunk-000" / f"file-{f:04d}.parquet")
        pq.write_table(pa.table(meta),
                       root / "meta" / "episodes" / "chunk-000.parquet")
        feature_names = ["j0", "j1", "j2", "j3", "j4", "gripper"]
        (root / "meta" / "info.json").write_text(json.dumps({
            "codebase_version": "v3.0", "repo_id": "t/tasks", "fps": 30,
            "total_episodes": ep,
            "features": {
                "observation.state": {"dtype": "float32", "shape": [6],
                                      "names": feature_names},
                "action": {"dtype": "float32", "shape": [6],
                           "names": feature_names},
            }}))
        return root

    def test_tasks_is_read_and_collapsed_to_a_hashable_group(self, tmp_path):
        """A list of strings is unhashable; `set(groups)` would fail on it."""
        from raftaar.calibration import episode_groups

        root = self._tasks_dataset(tmp_path)
        data = load_lerobot(root, spread=True)

        assert "tasks" in data["info"]["_adapter"]["grouping_keys"]
        groups = episode_groups(data, "tasks")
        assert groups is not None
        assert len(set(groups)) == 3            # hashable, and correct
        assert all(isinstance(g, str) for g in groups)

    def test_detector_recovers_a_task_partition_when_one_exists(self, tmp_path):
        """The positive control, end to end.

        Three tasks with genuinely different routes. If this does not recover
        the partition, a null result on a real multi-task dataset says nothing
        about the data.
        """
        from raftaar.calibration import calibration_report

        root = self._tasks_dataset(tmp_path, per_file=25, n_files=6,
                                   distinct=True)
        data = load_lerobot(root, spread=True)
        report = calibration_report(data, scan(data), "tasks")

        usable = [v for v in report["per_phase"].values() if v["usable"]]
        assert usable, "no phase produced a comparable split"
        assert max(v["adjusted_rand"] for v in usable) > 0.9

    def test_recovery_degrades_with_fewer_episodes_per_group(self, tmp_path):
        """Episodes *per group* is what the comparison has to work with.

        Same three tasks and the same trajectory differences, fewer episodes:
        recovery falls from near-perfect to partial. This is the quantitative
        version of why `droid_1.0.1` was a poor test -- 1.93 episodes per task
        leaves nothing to lock onto, however good the detector is.
        """
        from raftaar.calibration import calibration_report

        def best(n_files, per_file):
            root = self._tasks_dataset(tmp_path / f"n{n_files}x{per_file}",
                                       n_files=n_files, per_file=per_file,
                                       distinct=True)
            data = load_lerobot(root, spread=True)
            report = calibration_report(data, scan(data), "tasks")
            scores = [v["adjusted_rand"] for v in report["per_phase"].values()
                      if v["usable"]]
            return max(scores) if scores else 0.0

        many = best(6, 25)    # 150 episodes, 50 per task
        few = best(4, 15)     # 60 episodes, 20 per task
        assert many > few

    def test_phases_where_tasks_do_not_differ_report_one_mode(self, tmp_path):
        """Not every phase should split: the tasks only diverge mid-trajectory.

        A detector that found three modes everywhere would be responding to the
        grouping rather than to the trajectories.
        """
        from raftaar.calibration import calibration_report

        root = self._tasks_dataset(tmp_path, distinct=True)
        data = load_lerobot(root, spread=True)
        report = calibration_report(data, scan(data), "tasks")

        single = [v for v in report["per_phase"].values()
                  if v["n_detected_modes"] == 1]
        assert single, "expected at least one phase with no split"
        assert all(v["reason"] == "detector found a single strategy"
                   for v in single)


class TestColumnAliases:
    """Hub datasets do not agree on what the two core columns are called.

    `robomme` ships `state` / `actions` / `image` -- no `observation.` prefix
    and a plural `actions`. A reader matching only the canonical names skipped
    every episode and then reported "no usable episodes", which describes the
    reader rather than the dataset. Across 180 datasets there are 129 distinct
    feature key names and only four are universal.
    """

    def _dataset(self, tmp_path, state_name, action_name, n_episodes=20,
                 n_frames=40):
        import pyarrow as pa
        import pyarrow.parquet as pq

        root = tmp_path / f"{state_name}-{action_name}"
        (root / "meta").mkdir(parents=True, exist_ok=True)
        (root / "data" / "chunk-000").mkdir(parents=True, exist_ok=True)
        rng = np.random.default_rng(0)
        rows = {state_name: [], action_name: [], "episode_index": [],
                "frame_index": []}
        for ep in range(n_episodes):
            state = np.zeros((n_frames, 6), dtype="float32")
            for d in range(3):
                state[:, d] = np.linspace(0, 1, n_frames) * rng.uniform(-1, 1)
            gripper = np.ones(n_frames, dtype="float32")
            gripper[n_frames // 3: 2 * n_frames // 3] = 0.0
            state[:, 5] = gripper
            rows[state_name] += state.tolist()
            rows[action_name] += np.diff(
                state, axis=0, prepend=state[:1]).astype("float32").tolist()
            rows["episode_index"] += [ep] * n_frames
            rows["frame_index"] += list(range(n_frames))
        pq.write_table(pa.table(rows),
                       root / "data" / "chunk-000" / "file-0000.parquet")
        (root / "meta" / "info.json").write_text(json.dumps({
            "codebase_version": "v3.0", "repo_id": "t/aliases", "fps": 30,
            "total_episodes": n_episodes, "features": {}}))
        return root

    def test_canonical_names_still_work(self, tmp_path):
        root = self._dataset(tmp_path, "observation.state", "action")
        data = load_lerobot(root)
        assert len(data["episodes"]) == 20
        assert data["info"]["_adapter"]["state_key"] == "observation.state"
        assert data["info"]["_adapter"]["action_key"] == "action"

    def test_robomme_style_names_are_read(self, tmp_path):
        """`state` / `actions` -- the case that read as "no action column"."""
        root = self._dataset(tmp_path, "state", "actions")
        data = load_lerobot(root)
        assert len(data["episodes"]) == 20
        assert data["info"]["_adapter"]["state_key"] == "state"
        assert data["info"]["_adapter"]["action_key"] == "actions"

    def test_the_resolved_names_are_recorded(self, tmp_path):
        """Which columns were read is part of how the dataset was interpreted.

        Two scans that resolved different columns are not comparable, and the
        manifest is the only place that could say so.
        """
        canonical = load_lerobot(
            self._dataset(tmp_path, "observation.state", "action"))
        aliased = load_lerobot(self._dataset(tmp_path, "state", "actions"))

        assert canonical["info"]["_adapter"]["state_key"] == "observation.state"
        assert aliased["info"]["_adapter"]["state_key"] == "state"
        assert canonical["info"]["_adapter"]["action_key"] == "action"
        assert aliased["info"]["_adapter"]["action_key"] == "actions"

    def test_an_unreadable_dataset_says_what_it_looked_for(self, tmp_path):
        """"No usable episodes" alone describes the reader, not the data."""
        root = self._dataset(tmp_path, "foo", "bar")
        with pytest.raises(LeRobotFormatError) as exc:
            load_lerobot(root)
        message = str(exc.value)
        assert "no state/action column" in message
        assert "observation.state" in message      # what it tried
        assert "foo" in message and "bar" in message  # what it found
