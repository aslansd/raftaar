"""Tests for packaging, the CLI, reporting, and the optional integrations.

The theme is graceful degradation. Raftaar's core install is three
dependencies; matplotlib, Flask and daftar are all optional. Each of those
options has to be genuinely optional, which means tested with the package
absent, not just documented as optional.
"""

from __future__ import annotations

import json
import subprocess
import sys

import pytest

from raftaar import DatasetSpec, FaultSpec, build_dataset, load_dataset, scan


@pytest.fixture(scope="module")
def dataset(tmp_path_factory):
    tmp = tmp_path_factory.mktemp("data")
    spec = DatasetSpec(name="pkg", n_episodes=40, seed=3, faults=FaultSpec())
    return build_dataset(spec, tmp / "datasets")


class TestPublicAPI:
    def test_top_level_imports(self):
        import raftaar

        for name in ("scan", "DatasetSpec", "FaultSpec", "build_dataset",
                     "load_dataset"):
            assert hasattr(raftaar, name)
        assert raftaar.__version__

    def test_importing_raftaar_does_not_pull_matplotlib(self):
        """The core install has no plotting stack; importing must not need one."""
        code = (
            "import sys; import raftaar; "
            "assert 'matplotlib' not in sys.modules, "
            "'importing raftaar pulled matplotlib'; print('ok')"
        )
        out = subprocess.run([sys.executable, "-c", code],
                             capture_output=True, text=True)
        assert out.returncode == 0, out.stderr
        assert "ok" in out.stdout

    def test_importing_raftaar_does_not_pull_flask_or_torch(self):
        code = (
            "import sys, raftaar; "
            "bad = [m for m in ('flask', 'torch', 'gunicorn') if m in sys.modules]; "
            "assert not bad, bad; print('ok')"
        )
        out = subprocess.run([sys.executable, "-c", code],
                             capture_output=True, text=True)
        assert out.returncode == 0, out.stderr


class TestReporting:
    def test_markdown_report_needs_no_matplotlib(self, dataset, tmp_path):
        from raftaar.report import write_markdown

        report = scan(load_dataset(dataset))
        out = tmp_path / "report.md"
        write_markdown(report, out)

        text = out.read_text()
        assert "Raftaar" in text
        assert report["dataset"] in text

    def test_plot_raises_a_named_error_without_matplotlib(self, dataset, tmp_path,
                                                          monkeypatch):
        """The message has to name the fix, not just fail."""
        import builtins

        from raftaar.report import PlottingUnavailable, plot

        real_import = builtins.__import__

        def blocked(name, *a, **kw):
            if name == "matplotlib" or name.startswith("matplotlib."):
                raise ImportError("No module named 'matplotlib'", name="matplotlib")
            return real_import(name, *a, **kw)

        monkeypatch.setattr(builtins, "__import__", blocked)

        data = load_dataset(dataset)
        with pytest.raises(PlottingUnavailable) as exc:
            plot(data, scan(data), tmp_path / "x.png")
        assert "raftaar[plot]" in str(exc.value)


class TestCLI:
    def test_cli_entry_point_is_installed(self):
        out = subprocess.run(["raftaar", "--help"], capture_output=True,
                             text=True)
        assert out.returncode == 0
        for command in ("synth", "scan", "validate"):
            assert command in out.stdout

    def test_synth_then_scan_round_trip(self, tmp_path):
        synth = subprocess.run(
            ["raftaar", "synth", "cli_test", "--episodes", "30"],
            cwd=tmp_path, capture_output=True, text=True)
        assert synth.returncode == 0, synth.stderr

        scan_run = subprocess.run(
            ["raftaar", "scan", "datasets/cli_test", "--out", "out"],
            cwd=tmp_path, capture_output=True, text=True)
        assert scan_run.returncode == 0, scan_run.stderr

        report = json.loads((tmp_path / "out" / "report.json").read_text())
        assert report["n_episodes"] == 30
        assert (tmp_path / "out" / "report.md").exists()

    def test_synth_accepts_named_faults(self, tmp_path):
        out = subprocess.run(
            ["raftaar", "synth", "faulty", "--episodes", "30",
             "--faults", "bimodal_detour", "dead_actuator"],
            cwd=tmp_path, capture_output=True, text=True)
        assert out.returncode == 0, out.stderr
        assert (tmp_path / "datasets" / "faulty").exists()


class TestProvenanceIsOptional:
    def test_provenance_module_imports_without_daftar(self):
        from raftaar import provenance

        assert isinstance(provenance.available(), bool)

    def test_track_yields_none_when_daftar_is_absent(self, monkeypatch):
        from raftaar import provenance

        monkeypatch.setattr(provenance, "available", lambda: False)
        with provenance.track("x") as run:
            assert run is None

    def test_record_scan_is_a_noop_on_none(self):
        from raftaar import provenance

        provenance.record_scan(None, {"findings": []})  # must not raise

    def test_tracked_scan_matches_plain_scan(self, dataset):
        """Drop-in: the report is identical whether or not daftar is present."""
        from raftaar.provenance import tracked_scan

        plain = scan(load_dataset(dataset))
        tracked = tracked_scan(dataset, label="test-scan")

        assert set(plain) == set(tracked)
        assert plain["n_episodes"] == tracked["n_episodes"]
        assert ([f["id"] for f in plain["findings"]]
                == [f["id"] for f in tracked["findings"]])


class TestSynthEnvironment:
    def test_dataset_round_trips_through_disk(self, dataset):
        data = load_dataset(dataset)
        assert len(data["episodes"]) == 40
        assert "info" in data
        for episode in data["episodes"][:3]:
            assert len(episode["action"]) > 0
            assert len(episode["phase"]) == len(episode["action"])

    def test_same_seed_gives_the_same_dataset(self, tmp_path):
        """A synthetic environment used as ground truth has to be deterministic."""
        specs = [
            DatasetSpec(name=f"seeded{i}", n_episodes=20, seed=99,
                        faults=FaultSpec())
            for i in range(2)
        ]
        reports = [scan(load_dataset(build_dataset(s, tmp_path / f"d{i}")))
                   for i, s in enumerate(specs)]

        assert reports[0]["n_frames"] == reports[1]["n_frames"]
        assert ([f["id"] for f in reports[0]["findings"]]
                == [f["id"] for f in reports[1]["findings"]])

    def test_different_seeds_give_different_trajectories(self, tmp_path):
        """Frame counts match by design -- episodes have a fixed horizon -- so
        the comparison has to be on the trajectories themselves."""
        import numpy as np

        a = load_dataset(build_dataset(
            DatasetSpec(name="s1", n_episodes=20, seed=1, faults=FaultSpec()),
            tmp_path / "a"))
        b = load_dataset(build_dataset(
            DatasetSpec(name="s2", n_episodes=20, seed=2, faults=FaultSpec()),
            tmp_path / "b"))

        assert a["episodes"][0]["action"].shape == b["episodes"][0]["action"].shape
        assert not np.allclose(a["episodes"][0]["action"],
                               b["episodes"][0]["action"])


class TestWebTemplateBranding:
    """The masthead is split across a tag for the two-tone colour:

        <div class="brand">Raf<span>taar</span></div>

    which means the product name never appears as a contiguous string. A rename
    that searches for "DemoScope" silently misses it, and the page keeps the old
    brand while the <title> is correctly updated -- so it looks right in the tab
    and wrong on the page.

    This strips tags before comparing, which is the only way to catch it.
    """

    def _brand_text(self):
        import re
        from pathlib import Path

        template = (Path(__file__).resolve().parent.parent
                    / "web" / "templates" / "index.html")
        html = template.read_text(encoding="utf-8")
        match = re.search(r'<div class="brand">(.*?)</div>', html, re.S)
        assert match, "no .brand element in the template"
        return re.sub(r"<[^>]+>", "", match.group(1)).strip()

    def test_masthead_reads_raftaar_once_tags_are_stripped(self):
        assert self._brand_text() == "Raftaar"

    def test_no_former_name_survives_anywhere_in_the_template(self):
        import re
        from pathlib import Path

        template = (Path(__file__).resolve().parent.parent
                    / "web" / "templates" / "index.html")
        stripped = re.sub(r"<[^>]+>", "", template.read_text(encoding="utf-8"))
        for old in ("DemoScope", "demoscope", "KineLens", "kinelens"):
            assert old not in stripped, f"{old} still in the rendered text"


class TestFieldAuditReader:
    """Reading a published audit instead of guessing at metadata.

    The audit is not ours and its columns may be renamed, so the reader has to
    degrade rather than crash: an unparseable audit must behave as though it
    knows nothing, leaving the caller's own inference in place.
    """

    def _write(self, tmp_path, text):
        path = tmp_path / "names-audit.csv"
        path.write_text(text)
        return path

    def test_reads_gripper_indices(self, tmp_path):
        from raftaar.field_audit import load_audit

        path = self._write(tmp_path, (
            "dataset,names_quality,gripper_indices_action,gripper_indices_state\n"
            'lerobot/aloha,semantic,"[6, 13]","[6, 13]"\n'
            "lerobot/droid_1.0.1,semantic,7,7\n"
        ))
        audit = load_audit(path)
        assert audit.gripper_index("lerobot/aloha") == 6
        assert audit.gripper_index("lerobot/droid_1.0.1") == 7
        assert audit.quality_tier("lerobot/aloha") == "semantic"

    def test_not_determinable_is_none_not_a_guess(self, tmp_path):
        """'We looked and could not tell' must not become an index."""
        from raftaar.field_audit import load_audit

        path = self._write(tmp_path, (
            "dataset,names_quality,gripper_indices_state\n"
            "lerobot/pusht,absent,not determinable\n"
            "some/placeholder,placeholder,\n"
        ))
        audit = load_audit(path)
        assert audit.gripper_index("lerobot/pusht") is None
        assert audit.gripper_index("some/placeholder") is None
        assert audit.quality_tier("lerobot/pusht") == "absent"

    def test_bare_name_matches_org_qualified(self, tmp_path):
        from raftaar.field_audit import load_audit

        path = self._write(tmp_path, (
            "dataset,gripper_indices_state\nlerobot/droid_1.0.1,7\n"
        ))
        assert load_audit(path).gripper_index("droid_1.0.1") == 7

    def test_unknown_dataset_returns_none(self, tmp_path):
        from raftaar.field_audit import load_audit

        path = self._write(tmp_path, "dataset,gripper_indices_state\na/b,3\n")
        assert load_audit(path).gripper_index("not/in_audit") is None

    def test_renamed_columns_degrade_rather_than_crash(self, tmp_path):
        """The audit's schema is not ours to depend on."""
        from raftaar.field_audit import load_audit

        path = self._write(tmp_path, "dataset,something_else\na/b,3\n")
        audit = load_audit(path)
        assert audit.gripper_index("a/b") is None
        assert any("gripper" in m for m in audit.missing_columns)

    def test_missing_file_is_reported_not_raised(self, tmp_path):
        from raftaar.field_audit import load_audit

        audit = load_audit(tmp_path / "nope.csv")
        assert len(audit) == 0
        assert any("not found" in m for m in audit.missing_columns)

    def test_empty_file_is_reported(self, tmp_path):
        from raftaar.field_audit import load_audit

        audit = load_audit(self._write(tmp_path, ""))
        assert any("empty" in m for m in audit.missing_columns)
